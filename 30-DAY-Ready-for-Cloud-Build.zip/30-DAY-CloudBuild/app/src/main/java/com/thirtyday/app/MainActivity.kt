package com.thirtyday.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), SensorEventListener {
    private lateinit var webView: WebView
    private lateinit var sensorManager: SensorManager
    private var stepSensor: Sensor? = null
    private val prefs by lazy { getSharedPreferences("30day_steps", Context.MODE_PRIVATE) }
    private val permissionRequest = 301

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 16, 16)
        window.navigationBarColor = android.graphics.Color.rgb(16, 16, 16)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript("window.requestNativeSteps && window.requestNativeSteps();", null)
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(StepBridge(), "AndroidSteps")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (hasActivityPermission()) startStepSensor()
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    private fun hasActivityPermission(): Boolean {
        return Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED
    }

    private fun askActivityPermission() {
        if (Build.VERSION.SDK_INT >= 29 && !hasActivityPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), permissionRequest)
        } else {
            startStepSensor()
        }
    }

    private fun startStepSensor() {
        val sensor = stepSensor ?: return
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startStepSensor()
        } else if (requestCode == permissionRequest) {
            Toast.makeText(this, "يمكنك استخدام إدخال الخطوات اليدوي دون الإذن", Toast.LENGTH_LONG).show()
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_STEP_COUNTER) return
        val totalSinceBoot = event.values[0].toLong()
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val savedDate = prefs.getString("date", null)
        if (savedDate != today) {
            prefs.edit().putString("date", today).putLong("baseline", totalSinceBoot).apply()
        }
        val baseline = prefs.getLong("baseline", totalSinceBoot)
        val stepsToday = (totalSinceBoot - baseline).coerceAtLeast(0L)
        webView.post {
            webView.evaluateJavascript("window.setNativeSteps && window.setNativeSteps($stepsToday);", null)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    inner class StepBridge {
        @JavascriptInterface
        fun requestPermission() {
            runOnUiThread {
                if (stepSensor == null) {
                    Toast.makeText(this@MainActivity, "هذا الهاتف لا يحتوي على مستشعر عدّ الخطوات", Toast.LENGTH_LONG).show()
                } else {
                    askActivityPermission()
                }
            }
        }

        @JavascriptInterface
        fun hasSensor(): Boolean = stepSensor != null
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
